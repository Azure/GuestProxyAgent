# Important

The drive 'redirect.bpf.sys' must be signed manually currently, so if we have to make any code changes within this folder, we need manual sign the 'redirect.bpf.sys' from the build output folder.

## Get the new 'redirect.bpf.sys'

1. To get the release version of new redirect.bpf.sys from your local dev box, run ```build release clean```. 
2. copy the './out/release/redirect.bpf.sys' to sign it manually.

## Manual Sign the new 'redirect.bpf.sys'

<< To be defined later >>
